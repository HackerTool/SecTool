DAws  a php webshell

Author:[dotcppfile](https://github.com/dotcppfile/)

url:https://github.com/dotcppfile/DAws

There's multiple things that makes DAws better than every Web Shell out there:

![alt tag](http://i.imgur.com/nUmccKQ.png)

